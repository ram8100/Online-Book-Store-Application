Online Bookstore (fixed)

This archive contains the frontend and backend for the Online Bookstore project.
I made the following automatic fixes:
- Replaced a malformed pom.xml with a working Spring Boot 2.7.12 pom (Java 11).
- Added missing react-scripts dependency to frontend package.json so `npm install` will pull required scripts.

What I couldn't do in this environment:
- I could not run `npm install` or `mvn package` because the execution environment does not have Node.js/npm or Maven installed.
- I did not run the application or run tests; please run the build commands below on your machine.

How to build locally:
Backend (Java/Maven):
  1. Install JDK 11
  2. cd online-bookstore
  3. mvn -DskipTests package
  4. java -jar target/online-bookstore-0.0.1-SNAPSHOT.jar

Frontend (Node/Create React App):
  1. Install Node.js (v14+)
  2. cd online-bookstore-frontend
  3. npm install
  4. npm run build or npm start (for dev)

If you want, I can attempt further fixes (code-level) — tell me to run the build logs locally or paste compilation errors you see after running the above commands.

