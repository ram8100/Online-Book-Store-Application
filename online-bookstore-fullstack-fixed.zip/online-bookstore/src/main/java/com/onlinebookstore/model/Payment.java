package com.onlinebookstore.model;

import javax.persistence.*;
import lombok.*;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Payment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String paymentProvider;
    private String status;
    private Double amount;
    private Date paidAt;
}
