package com.onlinebookstore.security;

import io.jsonwebtoken.*;
import org.springframework.stereotype.Component;
import java.util.Date;
import java.util.function.Function;
import java.util.*;

@Component
public class JwtUtil {
    private final String SECRET = "REPLACE_THIS_SECRET_WITH_ENV_VAR";
    private final long EXPIRATION_MS = 1000L * 60 * 60 * 24; // 24 hours

    public String generateToken(String username, List<String> roles) {
        Claims claims = Jwts.claims().setSubject(username);
        claims.put("roles", roles);
        Date now = new Date();
        Date exp = new Date(now.getTime() + EXPIRATION_MS);
        return Jwts.builder().setClaims(claims).setIssuedAt(now).setExpiration(exp)
                .signWith(SignatureAlgorithm.HS256, SECRET.getBytes()).compact();
    }

    public boolean validateToken(String token) {
        try {
            Jwts.parser().setSigningKey(SECRET.getBytes()).parseClaimsJws(token);
            return true;
        } catch (JwtException | IllegalArgumentException ex) {
            return false;
        }
    }

    public String getUsername(String token) {
        return getClaim(token, Claims::getSubject);
    }

    public <T> T getClaim(String token, Function<Claims,T> claimsResolver) {
        Claims claims = Jwts.parser().setSigningKey(SECRET.getBytes()).parseClaimsJws(token).getBody();
        return claimsResolver.apply(claims);
    }
}
