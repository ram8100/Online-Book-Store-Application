package com.onlinebookstore.service;

import com.onlinebookstore.model.Book;
import com.onlinebookstore.repository.BookRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BookService {
    private final BookRepository bookRepository;

    // Explicit constructor for tests/mock usage
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public List<Book> listAll() { return bookRepository.findAll(); }
    public Book get(Long id) { return bookRepository.findById(id).orElse(null); }
    public Book save(Book b) { return bookRepository.save(b); }
    public void delete(Long id) { bookRepository.deleteById(id); }
    public List<Book> search(String q) { return bookRepository.findByTitleContainingIgnoreCase(q); }
}
