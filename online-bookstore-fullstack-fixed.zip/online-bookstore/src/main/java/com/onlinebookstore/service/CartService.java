package com.onlinebookstore/service;

import com.onlinebookstore.model.CartItem;
import com.onlinebookstore.model.Book;
import com.onlinebookstore.repository.CartItemRepository;
import com.onlinebookstore.repository.BookRepository;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CartService {
    private final CartItemRepository cartItemRepository;
    private final BookRepository bookRepository;

    public List<CartItem> getCart(String sessionId) {
        return cartItemRepository.findBySessionId(sessionId);
    }

    public CartItem addToCart(String sessionId, Long bookId, int qty) {
        Book b = bookRepository.findById(bookId).orElse(null);
        if (b == null) return null;
        CartItem ci = CartItem.builder().book(b).quantity(qty).sessionId(sessionId).build();
        return cartItemRepository.save(ci);
    }

    public void clearCart(String sessionId) {
        cartItemRepository.findBySessionId(sessionId).forEach(cartItemRepository::delete);
    }
}
