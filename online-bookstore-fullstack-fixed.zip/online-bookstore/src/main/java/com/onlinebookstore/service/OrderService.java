package com.onlinebookstore.service;

import com.onlinebookstore.model.*;
import com.onlinebookstore.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.*;

@Service
@RequiredArgsConstructor
public class OrderService {
    private final OrderRepository orderRepository;

    public OrderEntity placeOrder(String name, String email, List<CartItem> cartItems) {
        OrderEntity order = new OrderEntity();
        order.setCustomerName(name);
        order.setCustomerEmail(email);
        order.setPlacedAt(new Date());
        double total = 0;
        List<OrderItem> items = cartItems.stream().map(ci -> {
            OrderItem oi = OrderItem.builder()
                .bookTitle(ci.getBook().getTitle())
                .price(ci.getBook().getPrice())
                .quantity(ci.getQuantity())
                .build();
            return oi;
        }).collect(Collectors.toList());
        for (OrderItem oi : items) total += oi.getPrice() * oi.getQuantity();
        order.setTotalAmount(total);
        order.setItems(items);
        return orderRepository.save(order);
    }
}
