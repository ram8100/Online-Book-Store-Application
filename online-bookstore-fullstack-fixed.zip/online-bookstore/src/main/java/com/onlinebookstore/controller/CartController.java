package com.onlinebookstore.controller;

import com.onlinebookstore.service.CartService;
import com.onlinebookstore.service.OrderService;
import com.onlinebookstore.model.CartItem;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/cart")
@RequiredArgsConstructor
public class CartController {
    private final CartService cartService;
    private final OrderService orderService;

    @GetMapping
    public String viewCart(HttpSession session, Model model) {
        String sid = session.getId();
        List<CartItem> cart = cartService.getCart(sid);
        model.addAttribute("cart", cart);
        return "cart";
    }

    @PostMapping("/add")
    public String addToCart(@RequestParam Long bookId, @RequestParam(defaultValue = "1") int qty, HttpSession session) {
        cartService.addToCart(session.getId(), bookId, qty);
        return "redirect:/cart";
    }

    @PostMapping("/checkout")
    public String checkout(@RequestParam String name, @RequestParam String email, HttpSession session, Model model) {
        String sid = session.getId();
        List<CartItem> cart = cartService.getCart(sid);
        if (cart.isEmpty()) return "redirect:/cart";
        var order = orderService.placeOrder(name, email, cart);
        cartService.clearCart(sid);
        model.addAttribute("order", order);
        return "order-confirm";
    }
}
