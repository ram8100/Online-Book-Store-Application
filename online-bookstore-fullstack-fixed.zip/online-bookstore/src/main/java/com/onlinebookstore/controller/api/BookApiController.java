package com.onlinebookstore.controller.api;

import com.onlinebookstore.model.Book;
import com.onlinebookstore.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/books")
@RequiredArgsConstructor
public class BookApiController {
    private final BookService bookService;

    @GetMapping
    public List<Book> all() { return bookService.listAll(); }

    @GetMapping("/{id}")
    public Book get(@PathVariable Long id) { return bookService.get(id); }

    @PostMapping
    public Book create(@RequestBody Book b) { return bookService.save(b); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { bookService.delete(id); }
}
