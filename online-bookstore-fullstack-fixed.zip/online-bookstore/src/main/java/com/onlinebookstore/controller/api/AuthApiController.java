package com.onlinebookstore.controller.api;

import com.onlinebookstore.model.User;
import com.onlinebookstore.repository.UserRepository;
import com.onlinebookstore.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthApiController {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @PostMapping("/login")
    public Map<String,Object> login(@RequestBody Map<String,String> body) {
        String username = body.get("username");
        String password = body.get("password");
        Optional<User> ou = userRepository.findByUsername(username);
        if (ou.isEmpty()) {
            return Map.of("error","Invalid credentials");
        }
        User u = ou.get();
        if (!passwordEncoder.matches(password, u.getPassword())) {
            return Map.of("error","Invalid credentials");
        }
        List<String> roles = List.of(u.getRole());
        String token = jwtUtil.generateToken(username, roles);
        return Map.of("token", token, "username", username, "roles", roles);
    }
}
