package com.onlinebookstore.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;
import org.springframework.beans.factory.annotation.Value;

@RestController
@RequestMapping("/api/stripe")
public class StripeController {

    @Value("${stripe.secret:}")
    private String stripeSecret;

    @PostMapping("/create-payment-intent")
    public Map<String,Object> createPaymentIntent(@RequestBody Map<String,Object> body) {
        // If stripeSecret provided, server would call Stripe API to create a PaymentIntent and return clientSecret.
        // For demo / test mode, if no key is present, return a stub clientSecret.
        double amount = Double.parseDouble(body.getOrDefault("amount","0").toString());
        if (stripeSecret == null || stripeSecret.isBlank()) {
            return Map.of("clientSecret", "stub_client_secret_"+UUID.randomUUID().toString(), "amount", amount, "mode","stub");
        }
        // Real implementation (commented): use Stripe Java SDK to create PaymentIntent using stripeSecret.
        return Map.of("clientSecret", "live_client_secret_placeholder", "amount", amount, "mode","live");
    }
}
