package com.onlinebookstore.controller;

import com.onlinebookstore.service.BookService;
import com.onlinebookstore.model.Book;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@Controller
@RequestMapping("/books")
@RequiredArgsConstructor
public class BookController {
    private final BookService bookService;

    @GetMapping
    public String list(@RequestParam(required=false) String q, Model model) {
        List<Book> books = (q == null || q.isEmpty()) ? bookService.listAll() : bookService.search(q);
        model.addAttribute("books", books);
        model.addAttribute("q", q);
        return "books";
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model) {
        Book b = bookService.get(id);
        model.addAttribute("book", b);
        return "book-detail";
    }
}
