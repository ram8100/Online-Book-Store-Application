package com.onlinebookstore.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    // Simulate creating a payment session (like Razorpay / Stripe)
    @PostMapping("/create")
    public Map<String,Object> createPayment(@RequestBody Map<String,Object> body) {
        double amount = Double.parseDouble(body.getOrDefault("amount","0").toString());
        Map<String,Object> resp = new HashMap<>();
        resp.put("paymentId", UUID.randomUUID().toString());
        resp.put("amount", amount);
        resp.put("status", "CREATED");
        resp.put("provider", "STUB");
        resp.put("checkoutUrl", "/api/payments/checkout/" + UUID.randomUUID().toString());
        return resp;
    }

    // Simulate verifying payment
    @PostMapping("/verify")
    public Map<String,Object> verify(@RequestBody Map<String,Object> body) {
        Map<String,Object> resp = new HashMap<>();
        resp.put("paymentId", body.getOrDefault("paymentId",""));
        resp.put("status", "PAID");
        resp.put("provider", "STUB");
        return resp;
    }
}
