package com.onlinebookstore.controller.api;

import com.onlinebookstore.model.OrderEntity;
import com.onlinebookstore.model.CartItem;
import com.onlinebookstore.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.onlinebookstore.repository.CartItemRepository;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderApiController {
    private final OrderService orderService;
    private final CartItemRepository cartItemRepository;

    @PostMapping("/place")
    public OrderEntity place(@RequestParam String name, @RequestParam String email, @RequestParam String sessionId) {
        List<CartItem> cart = cartItemRepository.findBySessionId(sessionId);
        return orderService.placeOrder(name, email, cart);
    }
}
