package com.onlinebookstore.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.onlinebookstore.model.Book;
import com.onlinebookstore.repository.BookRepository;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {
    private final BookRepository bookRepository;

    @Override
    public void run(String... args) throws Exception {
        if (bookRepository.count() == 0) {
            bookRepository.save(Book.builder().title("Clean Code").author("Robert C. Martin").isbn("9780132350884").price(499.0).stock(10).description("A Handbook of Agile Software Craftsmanship").build());
            bookRepository.save(Book.builder().title("Effective Java").author("Joshua Bloch").isbn("9780134685991").price(599.0).stock(8).description("Best practices for Java platform").build());
            bookRepository.save(Book.builder().title("Head First Design Patterns").author("Eric Freeman").isbn("9780596007126").price(399.0).stock(5).description("A brain-friendly guide").build());
        }
    }
}
