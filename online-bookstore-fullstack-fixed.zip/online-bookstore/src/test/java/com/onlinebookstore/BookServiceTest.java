package com.onlinebookstore;

import com.onlinebookstore.model.Book;
import com.onlinebookstore.repository.BookRepository;
import com.onlinebookstore.service.BookService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

public class BookServiceTest {

    @Test
    void listAllReturnsBooks() {
        BookRepository repo = Mockito.mock(BookRepository.class);
        Mockito.when(repo.findAll()).thenReturn(Arrays.asList(
            Book.builder().id(1L).title("A").build()
        ));
        BookService svc = new BookService(repo);
        var list = svc.listAll();
        assertEquals(1, list.size());
        assertEquals("A", list.get(0).getTitle());
    }
}
