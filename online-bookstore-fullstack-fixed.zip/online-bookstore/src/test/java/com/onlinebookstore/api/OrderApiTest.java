package com.onlinebookstore.api;

import com.onlinebookstore.controller.api.OrderApiController;
import com.onlinebookstore.service.OrderService;
import com.onlinebookstore.repository.CartItemRepository;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.*;

@WebMvcTest(OrderApiController.class)
public class OrderApiTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrderService orderService;

    @MockBean
    private CartItemRepository cartItemRepository;

    @Test
    void placeOrderRequiresSessionId() throws Exception {
        mockMvc.perform(post("/api/orders/place")
                .param("name","Test")
                .param("email","a@b.com")
                .param("sessionId","sess123"))
            .andExpect(status().isOk());
    }
}
