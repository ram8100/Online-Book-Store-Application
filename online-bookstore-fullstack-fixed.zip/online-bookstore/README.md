# Online Bookstore Management System

## Description
A simple Online Bookstore Management System implemented with:
- Java (Spring Boot)
- MySQL
- Thymeleaf (server-side views)
- React (optional frontend)

## Features (added)
- User registration and persistent login (JPA-backed users with BCrypt)
- Payment gateway stub (simulates payment create/verify endpoints)
- REST API endpoints for books and orders
- Minimal React frontend that calls the REST API (located in `../online-bookstore-frontend`)
- Basic unit test and GitHub Actions CI workflow

## Setup (backend)
1. Install Java 11+, Maven, and MySQL.
2. Create MySQL database:
   ```sql
   CREATE DATABASE online_bookstore;
   ```
3. Update `src/main/resources/application.properties` with your MySQL username/password.
4. Build and run:
   ```bash
   mvn clean package
   java -jar target/online-bookstore-0.0.1-SNAPSHOT.jar
   ```
5. Open `http://localhost:8080` for server-side pages or run the React frontend.

## Frontend
- The React frontend is placed at `../online-bookstore-frontend`. To run:
  ```
  cd online-bookstore-frontend
  npm install
  npm start
  ```

## Notes
- For production, replace the payment stub with a real gateway (Stripe / Razorpay), enable CSRF, and secure endpoints.

## Stripe integration (demo)
- To test Stripe PaymentIntent, set `stripe.secret` in `application.properties` to your Stripe secret key.
- Update `src/main/resources/application.properties` with `stripe.secret=sk_test_xxx`.
- Update frontend `Checkout` publishable key `PUBLISHABLE_KEY` with your Stripe publishable key.

## JWT for API
- JWT util currently uses a hardcoded secret; for production, set a secure secret in environment and update JwtUtil to read from env.
- API login: POST `/api/auth/login` with JSON `{ "username":"...", "password":"..." }` returns `{ "token":"..." }`.
- Use `Authorization: Bearer <token>` for API requests.

## Tests
- Backend: `mvn test`
- Frontend E2E (Cypress): install Cypress in frontend and run `npx cypress open` or `npx cypress run`

## Security notes
- CSRF is enabled for web pages; API paths under `/api/**` are ignored for CSRF to allow REST clients — consider using proper CSRF protections or JWT-only APIs.
- Role-based access: ADMIN role required for modifying books via `/api/books/**`.
