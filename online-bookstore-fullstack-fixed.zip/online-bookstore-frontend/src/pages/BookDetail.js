import React, {useEffect, useState} from 'react';
import { useParams, Link } from 'react-router-dom';
function BookDetail(){
  const {id} = useParams();
  const [book,setBook]=useState(null);
  useEffect(()=> {
    fetch('/api/books/'+id).then(r=>r.json()).then(setBook);
  },[id]);
  function addToCart() {
    const cart = JSON.parse(localStorage.getItem('cart')||'[]');
    const found = cart.find(c=>c.id===book.id);
    if (found) found.qty += 1; else cart.push({id:book.id,title:book.title,price:book.price,qty:1});
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Added to cart');
  }
  if (!book) return <div>Loading...</div>;
  return (
    <div>
      <h2>{book.title}</h2>
      <p>Author: {book.author}</p>
      <p>Price: ₹{book.price}</p>
      <p>{book.description}</p>
      <button onClick={addToCart}>Add to cart</button>
      <div><Link to="/">Back</Link></div>
    </div>
  );
}
export default BookDetail;
