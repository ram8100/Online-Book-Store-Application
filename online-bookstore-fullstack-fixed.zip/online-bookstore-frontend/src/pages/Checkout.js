import React, {useState} from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

const PUBLISHABLE_KEY = "pk_test_sample_replace_with_yours";
const stripePromise = loadStripe(PUBLISHABLE_KEY);

function CheckoutForm(){
  const stripe = useStripe();
  const elements = useElements();
  const [name,setName]=useState('');
  const [email,setEmail]=useState('');
  const [status,setStatus]=useState('');
  const cart = JSON.parse(localStorage.getItem('cart')||'[]');
  const amount = cart.reduce((s,i)=> s + i.price * i.qty, 0);

  async function handleSubmit(e){
    e.preventDefault();
    setStatus('Creating payment...');
    // create payment intent on server
    const res = await fetch('/api/stripe/create-payment-intent', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({amount})
    });
    const data = await res.json();
    const clientSecret = data.clientSecret;
    setStatus('Processing with Stripe...');
    if (!stripe || !elements) {
      setStatus('Stripe not loaded');
      return;
    }
    // For demo: if clientSecret is stub, treat as success
    if (clientSecret && clientSecret.startsWith('stub_client_secret')) {
      // simulate success
      setStatus('Payment (stub) succeeded');
      localStorage.removeItem('cart');
      return;
    }
    // Real flow (if server provides clientSecret from Stripe)
    const card = elements.getElement(CardElement);
    const result = await stripe.confirmCardPayment(clientSecret, {
      payment_method: { card, billing_details: { name, email } }
    });
    if (result.error) {
      setStatus('Payment failed: ' + result.error.message);
    } else {
      if (result.paymentIntent && result.paymentIntent.status === 'succeeded') {
        setStatus('Payment succeeded!');
        localStorage.removeItem('cart');
      } else {
        setStatus('Payment status: ' + result.paymentIntent.status);
      }
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <div>
        Name: <input value={name} onChange={e=>setName(e.target.value)} required />
      </div>
      <div>
        Email: <input value={email} onChange={e=>setEmail(e.target.value)} type="email" required />
      </div>
      <div>
        <CardElement />
      </div>
      <button type="submit">Pay ₹{amount}</button>
      <div>{status}</div>
    </form>
  );
}

export default function Checkout(){
  return (
    <Elements stripe={stripePromise}>
      <h2>Checkout</h2>
      <CheckoutForm />
    </Elements>
  );
}
