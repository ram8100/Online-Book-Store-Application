import React, {useState, useEffect} from 'react';
import { Link, useNavigate } from 'react-router-dom';
function Cart(){
  const [cart,setCart]=useState([]);
  const navigate = useNavigate();
  useEffect(()=> setCart(JSON.parse(localStorage.getItem('cart')||'[]')), []);
  function remove(idx){
    const c = [...cart]; c.splice(idx,1); setCart(c); localStorage.setItem('cart', JSON.stringify(c));
  }
  function checkout() {
    navigate('/checkout');
  }
  const total = cart.reduce((s,i)=>s + i.price * i.qty, 0);
  return (
    <div>
      <h2>Your Cart</h2>
      {cart.length===0 && <div>Cart is empty</div>}
      <ul>
        {cart.map((c,idx)=> <li key={c.id}>{c.title} x {c.qty} - ₹{c.price} <button onClick={()=>remove(idx)}>Remove</button></li>)}
      </ul>
      <h3>Total: ₹{total}</h3>
      <button onClick={checkout}>Proceed to Checkout</button>
      <div><Link to="/">Continue shopping</Link></div>
    </div>
  );
}
export default Cart;
