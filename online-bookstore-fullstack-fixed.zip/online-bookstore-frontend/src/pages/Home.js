import React, {useEffect, useState} from 'react';
import { Link } from 'react-router-dom';
function Home(){
  const [books, setBooks] = useState([]);
  useEffect(()=> {
    fetch('/api/books').then(r=>r.json()).then(setBooks);
  },[]);
  function addToCart(book) {
    const cart = JSON.parse(localStorage.getItem('cart')||'[]');
    const found = cart.find(c=>c.id===book.id);
    if (found) found.qty += 1; else cart.push({id:book.id,title:book.title,price:book.price,qty:1});
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Added to cart');
  }
  return (
    <div>
      <h2>Books</h2>
      <ul>
        {books.map(b=> (
          <li key={b.id}>
            <Link to={`/books/${b.id}`}>{b.title}</Link> - ₹{b.price} 
            <button onClick={()=>addToCart(b)} style={{marginLeft:10}}>Add</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
export default Home;
