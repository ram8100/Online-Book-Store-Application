import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import BookDetail from './pages/BookDetail';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';

function App(){
  return (
    <div style={{padding:20}}>
      <header>
        <h1><Link to="/">Online Bookstore</Link></h1>
        <nav><Link to="/">Home</Link> | <Link to="/cart">Cart</Link></nav>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/books/:id" element={<BookDetail/>} />
          <Route path="/cart" element={<Cart/>} />
          <Route path="/checkout" element={<Checkout/>} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
