// Cypress E2E skeleton
describe('Online Bookstore E2E', () => {
  it('loads home and adds a book to cart', () => {
    cy.visit('http://localhost:3000');
    cy.contains('Books');
    // This is a scaffold; adapt selectors for real app.
  });
});
